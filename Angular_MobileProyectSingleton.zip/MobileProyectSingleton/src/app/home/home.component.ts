import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Movil } from '../models/Movil';
import { SummarizedMovilDTO } from '../models/SummarizedMovilDTO';
import { MatDialog } from '@angular/material/dialog';
import { MovilDetailsComponent } from '../components/movil-details/movil-details.component';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {
  trendingMobiles: SummarizedMovilDTO[] = [];
  allMoviles: Movil[] = [];

  constructor(private apiService: ApiService, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.apiService.getTrendingMobiles().subscribe((data: SummarizedMovilDTO[]) => {
      this.trendingMobiles = data;
    });
    this.apiService.getAllMobiles().subscribe((data: Movil[]) => {
      this.allMoviles = data;
    });
  }
  openMovilDetails(movil: Movil): void {
    this.dialog.open(MovilDetailsComponent, {
      width: '600px', // Ancho del diálogo
      data: { movil }, // Pasa el móvil seleccionado al diálogo
    });
  }
}
