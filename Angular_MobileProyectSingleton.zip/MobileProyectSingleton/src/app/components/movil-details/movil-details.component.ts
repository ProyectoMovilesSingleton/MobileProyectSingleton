import { Component, Inject } from '@angular/core';
import { Movil } from '../../models/Movil';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-movil-details',
  standalone: false,
  templateUrl: './movil-details.component.html',
  styleUrl: './movil-details.component.css'
})
export class MovilDetailsComponent {
  movil: Movil;

  constructor(@Inject(MAT_DIALOG_DATA) public data: { movil: Movil }) {
    this.movil = data.movil;
  }
}
