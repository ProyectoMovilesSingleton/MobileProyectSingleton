import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { Movil } from '../models/Movil';

@Component({
  selector: 'app-compare',
  standalone: false,
  templateUrl: './compare.component.html',
  styleUrl: './compare.component.css'
})
export class CompareComponent implements OnInit{

  allMoviles: Movil[] = []
  movil1: Movil | null = null; // Primer móvil seleccionado
  movil2: Movil | null = null; // Segundo móvil seleccionado

  constructor(private movilService: ApiService) {}

  ngOnInit(): void {
    this.loadAllMoviles(); // Cargar todos los móviles al iniciar el componente
  }

  // Método para cargar todos los móviles
  loadAllMoviles(): void {
    this.movilService.getAllMobiles().subscribe(
      (data) => {
        this.allMoviles = data; // Asignar los datos a la lista
      },
      (error) => {
        console.error('Error al obtener los móviles:', error);
      }
    );
  }

  // Método para seleccionar el primer móvil
  selectMovil1(movil: Movil): void {
    this.movil1 = movil;
  }

  // Método para seleccionar el segundo móvil
  selectMovil2(movil: Movil): void {
    this.movil2 = movil;
  }

  // Método para comparar dos valores numéricos o booleanos
  compareValues(value1: any, value2: any): string {
    if (typeof value1 === 'number' && typeof value2 === 'number') {
      if (value1 > value2) {
        return 'text-success'; // Verde si es mayor
      } else if (value1 < value2) {
        return 'text-danger'; // Rojo si es menor
      }
    } else if (typeof value1 === 'boolean' && typeof value2 === 'boolean') {
      if (value1 && !value2) {
        return 'text-success'; // Verde si es true y el otro es false
      } else if (!value1 && value2) {
        return 'text-danger'; // Rojo si es false y el otro es true
      }
    }
    return ''; // Sin estilo si son iguales o no son comparables
  }
}
