
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SummarizedMovilDTO } from '../models/SummarizedMovilDTO';
import { MovilFilterDTO } from '../models/MovilFilterDTO';
import { Movil } from '../models/Movil';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8080'; // URL de tu API de Spring Boot

  constructor(private http: HttpClient) {}

  getAllMobiles(): Observable<any> {
    return this.http.get(`${this.apiUrl}/moviles/all`);
  }
  getTrendingMobiles(): Observable<any> {
    return this.http.get(`${this.apiUrl}/moviles/getfive`);
  }
  filtrarMoviles(filtro: any): Observable<Movil[]> {
    return this.http.post<Movil[]>(`${this.apiUrl}/moviles/filtrar`, filtro);
  }

  // Método para obtener móviles filtrados
  getFilteredMobiles(filters: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/api/moviles/filtrar`, { params: filters });
  }

  // Método para obtener móviles anunciados
  getAnnouncedMobiles(): Observable<any> {
    return this.http.get(`${this.apiUrl}/api/moviles/anunciados`);
  }

  // Método para enviar una solicitud de intercambio
  sendRequest(request: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/api/solicitudes`, request);
  }

  // Método para obtener solicitudes enviadas y recibidas
  getRequests(): Observable<any> {
    return this.http.get(`${this.apiUrl}/api/solicitudes`);
  }
  getMarcas(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/api/moviles/marcas`);
  }
}
