import { Dimension } from "./Dimension";
import { Pantalla } from "./Pantalla";
import { Procesador } from "./Procesador";

export interface Movil {
  id?: number;
  marca: string;
  modelo: string;
  almacenamiento: number;
  ram: number;
  peso: number;
  camara: number;
  miliAmperios: number;
  nfc: boolean;
  precio: number;
  fechaLanzamiento: string; // o Date
  visualizaciones: number;
  procesador: Procesador;
  pantalla: Pantalla;
  dimension: Dimension;
}
