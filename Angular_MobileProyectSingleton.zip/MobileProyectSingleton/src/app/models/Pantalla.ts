export interface Pantalla {
  id?: number; // Opcional porque se ignora en JSON
  tamanno: number;
  tecnologia: string;
}
