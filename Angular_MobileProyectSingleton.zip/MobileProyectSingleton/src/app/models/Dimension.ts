export interface Dimension {
  id?: number; // Opcional porque se ignora en JSON
  grosor: number;
  ancho: number;
  alto: number;
}
