export interface MovilFilterDTO {
  precioMin: number | null;
  precioMax: number | null;
  ram: number | null;
  nfc: boolean | null;
  tecnologiaPantalla: string | null;
  marca: string | null;
}
