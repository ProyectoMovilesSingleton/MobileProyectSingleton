export interface Procesador {
  id?: number; // Opcional porque se ignora en JSON
  tipo: string;
  nucleos: number;
  velocidadMaxima: number;
}
