export interface SummarizedMovilDTO {
  marca: string;
  modelo: string;
  nucleosProcesador: number;
  ram: number;
  almacenamiento: number;
  precio: number;
}
