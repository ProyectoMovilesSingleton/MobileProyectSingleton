import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-requests',
  standalone: false,
  templateUrl: './requests.component.html',
  styleUrl: './requests.component.css'
})
export class RequestsComponent implements OnInit {
  sentRequests: any[] = [];
  receivedRequests: any[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.apiService.getRequests().subscribe((data: any) => {
      this.sentRequests = data.sent;
      this.receivedRequests = data.received;
    });
  }
}
