import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MovilFilterDTO } from '../models/MovilFilterDTO';
import { Movil } from '../models/Movil';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-filter',
  standalone: false,
  templateUrl: './filter.component.html',
  styleUrl: './filter.component.css'
})
export class FilterComponent {
  filtro = {
    precioMin: 0.0,
    precioMax: 100000.0,
    ram: null,
    nfc: null,
    tecnologiaPantalla: null,
    marca: '',
  };

  resultados: Movil[] = []; // Resultados de la búsqueda

  constructor(private apiService: ApiService) {}

  // Método para enviar el filtro al backend
  filtrar(): void {
    this.apiService.filtrarMoviles(this.filtro).subscribe(
      (data) => {
        this.resultados = data; // Asignar los resultados
      },
      (error) => {
        console.error('Error al filtrar móviles:', error);
      }
    );
  }
}
