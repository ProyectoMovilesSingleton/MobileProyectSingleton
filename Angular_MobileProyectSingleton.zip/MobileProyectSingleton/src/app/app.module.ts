import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdsComponent } from './ads/ads.component';
import { FilterComponent } from './filter/filter.component';
import { CompareComponent } from './compare/compare.component';
import { RequestsComponent } from './requests/requests.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog'; // Diálogos
import { MatButtonModule } from '@angular/material/button'; // Botones
import { MatCardModule } from '@angular/material/card';
import { MovilDetailsComponent } from './components/movil-details/movil-details.component'; // Tarjetas

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    AdsComponent,
    FilterComponent,
    CompareComponent,
    RequestsComponent,
    HeaderComponent,
    FooterComponent,
    MovilDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatCardModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
