import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RequestsComponent } from './requests/requests.component';
import { CompareComponent } from './compare/compare.component';
import { AdsComponent } from './ads/ads.component';
import { FilterComponent } from './filter/filter.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'ads', component: AdsComponent },
  { path: 'filter', component: FilterComponent },
  { path: 'compare', component: CompareComponent },
  { path: 'requests', component: RequestsComponent },
  { path: '**', component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
